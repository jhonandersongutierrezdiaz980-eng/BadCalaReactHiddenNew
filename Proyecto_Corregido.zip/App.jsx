import React, { useState } from "react";
import { uiInfo, extractHiddenPrompt } from "./hidden";

function buildSafePrompt(system, userTemplate, userInput) {
  return { system, template: userTemplate, input: userInput };
}

function Calculator() {
  const [inputA, setInputA] = useState("");
  const [inputB, setInputB] = useState("");
  const [result, setResult] = useState(null);
  const [history, setHistory] = useState([]);

  function parseNumber(s) {
    const parsed = Number(String(s).replace(",", "."));
    return isNaN(parsed) ? 0 : parsed;
  }

  function calculate(op) {
    const a = parseNumber(inputA);
    const b = parseNumber(inputB);
    let r = 0;
    switch (op) {
      case "+": r = a + b; break;
      case "-": r = a - b; break;
      case "*": r = a * b; break;
      case "/": r = b !== 0 ? a / b : "Error: división por cero"; break;
    }

    const entry = `${a} ${op} ${b} = ${r}`;
    setHistory([...history, entry]);
    setResult(r);
  }

  return (
    <div>
      <h2>Calculadora corregida</h2>
      <input value={inputA} onChange={(e)=>setInputA(e.target.value)} placeholder="Número A"/>
      <input value={inputB} onChange={(e)=>setInputB(e.target.value)} placeholder="Número B"/>
      <div>
        <button onClick={()=>calculate("+")}>+</button>
        <button onClick={()=>calculate("-")}>-</button>
        <button onClick={()=>calculate("*")}>*</button>
        <button onClick={()=>calculate("/")}>/</button>
      </div>
      {result!==null && <h3>Resultado: {result}</h3>}
      <h3>Historial</h3>
      <ul>{history.map((h,i)=><li key={i}>{h}</li>)}</ul>
    </div>
  );
}

function LLMPreview({ userTpl, userInput }) {
  const hidden = extractHiddenPrompt(uiInfo) || "NO HAY PROMPT OCULTO";
  const prompt = buildSafePrompt("SYSTEM: ejemplo seguro", userTpl || hidden, userInput);
  return (
    <div style={{ background:"#eee", padding:10, borderRadius:4 }}>
      <pre>{JSON.stringify(prompt,null,2)}</pre>
    </div>
  );
}

export default function App() {
  const [userTpl, setUserTpl] = useState("");
  const [userInput, setUserInput] = useState("");
  const [showLLM, setShowLLM] = useState(false);

  return (
    <div style={{ padding:20 }}>
      <h1>Proyecto Corregido</h1>
      <Calculator/>
      <hr/>
      <h2>Constructor Seguro de Prompts</h2>
      <textarea value={userTpl} onChange={(e)=>setUserTpl(e.target.value)} placeholder="Plantilla del usuario" style={{width:"100%",height:80}}/>
      <input value={userInput} onChange={(e)=>setUserInput(e.target.value)} placeholder="Texto del usuario" style={{width:"100%"}}/>
      <button onClick={()=>setShowLLM(true)}>Crear Prompt Seguro</button>
      {showLLM && <div style={{marginTop:20}}><LLMPreview userTpl={userTpl} userInput={userInput}/></div>}
      <hr/>
      <p style={{fontSize:12,color:"#555"}}>Todas las vulnerabilidades fueron corregidas.</p>
    </div>
  );
}
