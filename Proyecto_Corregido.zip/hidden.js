export const uiInfo = "No sensitive data"; 
export function extractHiddenPrompt(x){ return null; }
